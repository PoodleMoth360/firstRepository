function setup() {
  createCanvas(450, 450);
}

function draw() {
  background(120);
  strokeWeight(80);
  strokeCap(ROUND);
  point(250, 60);
  strokeWeight(2);
  line(150, 60, 200, 60);
  line(300, 60, 350, 60);
  line(250, 110, 250, 160);
  line(250, 10, 250, 0);

  strokeWeight(0);
  ellipse(134, 57, 6, 6);
  ellipse(338, 34, 6, 6);
  ellipse(23, 78, 6, 6);
  ellipse(412, 26, 6, 6);
  ellipse(79, 87, 6, 6);
  ellipse(167, 97, 6, 6);
  ellipse(97, 12, 6, 6);
  ellipse(368, 45, 6, 6);
  ellipse(400, 105, 6, 6);
  
  strokeWeight(0.1);
  strokeCap(SQUARE);
  quad(350, 150, 450, 150, 450, 450, 350, 450);
  strokeWeight(0.5);
  quad(230, 220, 370, 220, 370, 450, 230, 450);
  quad(0, 170, 120, 170, 120, 450, 0, 450);
  quad(100, 250, 240, 250, 240, 450, 100, 450);
  
  strokeWeight(1);
  line(170, 250, 170, 210);
  strokeWeight(7);
  point(170, 210);
  
}

