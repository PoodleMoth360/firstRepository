var num = [25];
var x = [];
var y = [];

function setup() {
  createCanvas(500, 500);
  stroke('black');
  strokeWeight(2);
  fill(255, 200, 105);
  
  for (var i = 0; i < num; i++){
    x[i] = 0;
    y[i] = 0;
  }
  
print(x.length);
print(y.length);
print(num.length);
  
}


function draw() {
  background('black');
  strokeWeight(11);
  stroke(220, 80, 240);
    point(90, 110);
  point(200, 90);
  point(280, 100);
  point(340, 70);
  point(160, 60);
  point(410, 80);
  point(50, 50);
  point(450, 100);
  
  
  stroke('black');
  strokeWeight(1.3);
  fill(220, 185, 140);
  rect(1, 280, 500, 280);
    fill(140);
  line(1, 280, 500, 280);
  quad(130, 130, 270, 130, 300, 280, 160, 280);
  triangle(111, 130, 290, 130, 220, 100);
  fill('yellow');
  rect(200, 200, 50, 80, 5);
      fill(170, 150, 60);
  strokeWeight(0);
  arc(360, 60, 90, 90, -1.52, -4.75);
  
  for (var i = num-1; i > 0; i--){
    x[i] = x[i-1];
    y[i] = y[i-1];
  }
  x[0] = mouseX;
  y[0] = mouseY;
  for (var i = 0; i < num; i++){
    fill(i * 40.5, 190, 150);
    rect(x[i], y[i], 75, 75, 15);
      fill(4.5, 220, 150);
    strokeWeight(0);
    rect(x[i]+30, y[i]-21, 10, 25, 15);
    ellipse(x[i] +84, y[i] +19, 12, 35);
    ellipse(x[i] +84, y[i] +39, 12, 35);
    ellipse(x[i] -4, y[i] +23, 12, 35);
    ellipse(x[i] +10, y[i] +7, 35, 12);
    ellipse(x[i] +18, y[i] +2, 35, 12);
    ellipse(x[i] +55, y[i] +1, 35, 12);
    ellipse(x[i] +80, y[i] +3, 35, 12);
      fill('black');
    strokeWeight(1.3);
    ellipse(x[i] +50, y[i] +26, 15, 25);
    ellipse(x[i] +25, y[i] +26, 15, 25);
      noFill();
    arc(x[i]+40, y[i]+45, 25, 15, 0, radians(180));
  }
  
}