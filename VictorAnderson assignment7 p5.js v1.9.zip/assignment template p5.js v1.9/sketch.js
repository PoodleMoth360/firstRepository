  var bladeNum = 0

function setup() {
  	createCanvas(750, 600);
    
  print(bladeNum);
  var bladeTotal = calculateBlades(bladeNum);
  print(bladeTotal);

}


function draw() {

	background(204, 106, 402);
  strokeWeight(0);
  strokeCap(ROUND);
    angleMode(DEGREES);
  scale(1);
  
  for (var x = -20; x < width + 375; x += 630) {
    bladeWheelOffset(x, -320);
    
	}
  
  for (var y = 200; y < width + 75; y += 630) {
    bladeWheelOffset(305, y);
	}
  
}



function blade(x, y){
  push();
translate(x, y);  
  scale(0.65);
  
  strokeCap(SQUARE);
  strokeWeight(7);
  stroke(205);
  fill(205);

  line (0, 82, 0, -53);
  
  strokeWeight(0);
  quad(0, -59, 4, -51, 0, -45, -4, -51);
  
  strokeWeight(5);
  stroke(170, 120, 100);
  line(-10, 82, 10, 82);
  
  strokeCap(ROUND);
  line(0, 82, 0, 104);
  
  strokeCap(SQUARE);
  strokeWeight(1.5);
  stroke(125);
  line (1, 81, 1, -52);
  
  pop();
}

function bladeWheel(x, y){
  push();
  translate(x/2, y/2);
  
  blade(250, 250);
    rotate(90);
blade(170, -180);
  rotate(90);
  blade(-250, -95);
  rotate(90);
  blade(-170, 320);
  
  pop();
    bladeNum +=4;
}

function bladeWheelOffset(x, y){
  push();
  translate(x/2, y/2)
  
  bladeWheel(-200, 270);
  rotate(-45);
  bladeWheel(-720, 300);
  
  pop();
  bladeNum +=8;
}

function calculateBlades(bladeNum){
  
  bladeTotal = bladeNum += 8*3;
  return bladeTotal;
  
}

