function setup() {
  createCanvas(555, 555);
  colorMode(RGB, 255, 255, 255, 1);
  background(0, 200, 200, 1);
}

function draw() {
  fill(200, 50, 250);
  strokeCap(ROUND);
  stroke('black');
  strokeWeight(2);
  triangle(120, 200, 230, 200, 175, 260);
  noStroke();
  ellipse(175, 175, 125, 125);
  strokeCap(ROUND);
  stroke('black');
  strokeWeight(2);
  arc(150, 170, 20, 20, 0, radians(180));
  arc(200, 170, 20, 20, 0, radians(180));
  arc(175, 205, 30, 30, 0, radians(180));
  noFill()
  bezier(175, 260, 240, 370, 150, 320,175, 500);
  
  fill('yellow');
  strokeCap(ROUND);
  stroke('black');
  strokeWeight(2);
  triangle(340, 310, 440, 310, 390, 360);
  noStroke();
  ellipse(390, 280, 125, 125);
  fill('black');
  ellipse(371, 280, 15, 15);
  ellipse(410, 280, 15, 15);
  fill(240, 100, 150);
  arc(390, 312, 30, 20, 0, radians(180));
  noFill();
  strokeCap(ROUND);
  stroke('black');
  strokeWeight(2);
  bezier(390, 360, 370, 390, 400, 420, 390, 535);
  
}